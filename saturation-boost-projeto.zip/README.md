# Saturation Boost

Mod Fabric (client-side) para Minecraft 26.3 que aumenta a saturacao das cores.

- Usa o sistema de efeitos de tela do proprio Minecraft (o mesmo da visao de aranha).
- Nao mexe no renderizador de chunks, entao e compativel com **Sodium**, Iris-less setups, EMF/ETF, ImmediatelyFast etc.
- Atua so no mundo; o HUD/inventario nao e afetado.
- Nao tem nenhum passo de "nitidez" nem mexe no item da mao.

## Uso (no jogo, pelo chat)

| Comando | O que faz |
|---|---|
| `!sat 130` | satura 130% (100 = normal, maximo 300, passos de 10) |
| `!sat off` | desliga |
| `!sat` | mostra o valor atual |

O valor fica salvo em `config/saturationboost.properties` (padrao: 130).

## Como gerar o .jar (sem PC, so com o GitHub)

1. Crie um repositorio novo e vazio em github.com (ex.: `saturation-boost`).
2. Crie cada arquivo pelo botao **Add file > Create new file**, digitando o caminho completo no nome (ex.: `src/main/java/dev/saturationboost/SaturationBoost.java`) e colando o conteudo:
   - `build.gradle`, `settings.gradle`, `gradle.properties`
   - `.github/workflows/build.yml`
   - `tools/gen_shaders.py`
   - `src/main/resources/fabric.mod.json`
   - `src/main/resources/saturationboost.mixins.json`
   - `src/main/java/dev/saturationboost/SaturationBoost.java`
   - `src/main/java/dev/saturationboost/mixin/GameRendererInvoker.java`
3. Ao salvar, a aba **Actions** roda sozinha (leva uns 3-6 min). Os shaders sao gerados la pelo `gen_shaders.py`.
4. Abra a execucao, desca ate **Artifacts** e baixe `saturation-boost-jar`. Dentro do zip esta `saturation-boost-1.0.0.jar` (ignore o `-sources`).
5. Importe o `.jar` na pasta de mods do launcher, junto com Fabric API.

Num PC, e so enviar a pasta inteira ao repositorio (ou rodar `python3 tools/gen_shaders.py` e `gradle build`).

## Se algo der errado

Eu nao consegui compilar nem testar com o Minecraft 26.3 de verdade; o codigo foi escrito a partir dos nomes do Minecraft 1.21.x/26.x. Pontos mais provaveis de ajuste:

- **Erro de compilacao em `Identifier`:** se o log disser que `net.minecraft.resources.Identifier` nao existe, troque por `net.minecraft.resources.ResourceLocation` (e `fromNamespaceAndPath` continua igual) nos dois arquivos .java.
- **Jogo fecha ao abrir (erro de Mixin citando `setPostEffect` ou `clearPostEffect`):** o nome desse metodo mudou na 26.3. Mande o `latest.log`.
- **Efeito nao aparece, sem crash:** mande o log (procure por `saturationboost` ou `post_effect`).
- Se o Actions falhar, baixe o artifact `build-log` e me envie.

Licenca: MIT.
