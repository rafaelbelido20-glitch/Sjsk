#!/usr/bin/env python3
"""Gera os shaders e os post_effect do mod (um por nivel de saturacao).

Niveis: 110, 120, ... 300  (100 = desligado, nao precisa de arquivo).
Cada nivel tem o valor fixo dentro do shader, sem uniforms, para reduzir
pontos de falha.

Uso (a partir da raiz do projeto):  python3 tools/gen_shaders.py
"""
import json
import pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
ASSETS = ROOT / "src" / "main" / "resources" / "assets" / "saturationboost"
SHADERS = ASSETS / "shaders" / "post"
EFFECTS = ASSETS / "post_effect"

SAT_SHADER = """#version 330

uniform sampler2D InSampler;

in vec2 texCoord;

out vec4 fragColor;

const float SATURATION = {sat};

void main() {{
    vec4 color = texture(InSampler, texCoord);
    float luma = dot(color.rgb, vec3(0.2126, 0.7152, 0.0722));
    vec3 result = mix(vec3(luma), color.rgb, SATURATION);
    fragColor = vec4(clamp(result, 0.0, 1.0), color.a);
}}
"""

COPY_SHADER = """#version 330

uniform sampler2D InSampler;

in vec2 texCoord;

out vec4 fragColor;

void main() {
    fragColor = texture(InSampler, texCoord);
}
"""


def effect(level: int) -> dict:
    return {
        "targets": {"swap": {}},
        "passes": [
            {
                "vertex_shader": "minecraft:core/screenquad",
                "fragment_shader": f"saturationboost:post/sat_{level}",
                "inputs": [{"sampler_name": "In", "target": "minecraft:main"}],
                "output": "swap",
            },
            {
                "vertex_shader": "minecraft:core/screenquad",
                "fragment_shader": "saturationboost:post/copy",
                "inputs": [{"sampler_name": "In", "target": "swap"}],
                "output": "minecraft:main",
            },
        ],
    }


def main() -> None:
    SHADERS.mkdir(parents=True, exist_ok=True)
    EFFECTS.mkdir(parents=True, exist_ok=True)

    (SHADERS / "copy.fsh").write_text(COPY_SHADER)

    count = 0
    for level in range(110, 301, 10):
        sat = level / 100.0
        (SHADERS / f"sat_{level}.fsh").write_text(SAT_SHADER.format(sat=f"{sat:.2f}"))
        (EFFECTS / f"saturation_{level}.json").write_text(
            json.dumps(effect(level), indent=2) + "\n"
        )
        count += 1
    print(f"Gerados {count} niveis (110-300) + copy.fsh")


if __name__ == "__main__":
    main()
