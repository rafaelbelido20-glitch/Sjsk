package dev.saturationboost.mixin;

import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/**
 * Da acesso aos metodos do proprio Minecraft que ligam/desligam um efeito de
 * pos-processamento. Nao altera nenhum codigo do jogo nem do Sodium: so chama
 * o que o vanilla ja usa para os efeitos de tela (ex.: visao de aranha).
 */
@Mixin(GameRenderer.class)
public interface GameRendererInvoker {

	@Invoker("setPostEffect")
	void saturationboost$setPostEffect(Identifier id);

	@Invoker("clearPostEffect")
	void saturationboost$clearPostEffect();
}
