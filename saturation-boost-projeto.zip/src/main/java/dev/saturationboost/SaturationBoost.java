package dev.saturationboost;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * Saturation Boost: aumenta a saturacao da imagem final do jogo.
 *
 * Controle (chat):  !sat 130   ->  130% de saturacao (100 = normal, maximo 300)
 *                   !sat off   ->  desliga
 *                   !sat       ->  mostra o valor atual
 *
 * Os metodos internos do Minecraft sao chamados por reflexao: se algum nome
 * mudar numa versao futura, o mod avisa no chat em vez de impedir o jogo de abrir.
 */
public class SaturationBoost implements ClientModInitializer {

	public static final String MOD_ID = "saturationboost";
	private static final int MIN = 100;
	private static final int MAX = 300;
	private static final int STEP = 10;

	/** 100 = desligado. */
	private static int level = 130;
	private static boolean effectOn = false;
	private static int tickCounter = 0;

	private static boolean lookedUp = false;
	private static boolean reported = false;
	private static Method setPostEffect;
	private static Method clearPostEffect;
	private static String lookupNote = "";

	@Override
	public void onInitializeClient() {
		loadConfig();
		ClientSendMessageEvents.ALLOW_CHAT.register(SaturationBoost::onChat);
		ClientTickEvents.END_CLIENT_TICK.register(SaturationBoost::onTick);
	}

	// ---------------------------------------------------------------- chat

	/** Retorna false para impedir o envio da mensagem ao servidor. */
	private static boolean onChat(String message) {
		String text = message.trim();
		if (!text.equalsIgnoreCase("!sat") && !text.toLowerCase().startsWith("!sat ")) {
			return true;
		}

		String arg = text.length() > 4 ? text.substring(4).trim() : "";
		if (arg.isEmpty()) {
			say("Saturacao atual: " + level + "%  (uso: !sat 100-300, !sat off)");
			return false;
		}

		if (arg.equalsIgnoreCase("off")) {
			level = MIN;
		} else {
			try {
				int value = Integer.parseInt(arg.replace("%", ""));
				level = snap(value);
			} catch (NumberFormatException e) {
				say("Valor invalido. Use: !sat 100-300  ou  !sat off");
				return false;
			}
		}

		saveConfig();
		reported = false;
		apply(Minecraft.getInstance(), true);
		say(level <= MIN ? "Saturacao desligada." : "Saturacao: " + level + "%");
		return false;
	}

	private static int snap(int value) {
		int clamped = Math.max(MIN, Math.min(MAX, value));
		return Math.round(clamped / (float) STEP) * STEP;
	}

	/** Mostra uma mensagem so para o jogador (nao vai ao servidor). */
	private static void say(String text) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null) {
			return;
		}
		Component msg = Component.literal("[Saturation Boost] " + text);
		if (invokeByName(mc.player, "sendSystemMessage", msg)) {
			return;
		}
		if (invokeByName(mc.player, "displayClientMessage", msg, Boolean.FALSE)) {
			return;
		}
		try {
			Object gui = Minecraft.class.getField("gui").get(mc);
			Object chat = gui.getClass().getMethod("getChat").invoke(gui);
			invokeByName(chat, "addMessage", msg);
		} catch (ReflectiveOperationException | RuntimeException ignored) {
			// sem como mostrar mensagem nesta versao
		}
	}

	private static boolean invokeByName(Object target, String name, Object... args) {
		for (Method m : target.getClass().getMethods()) {
			if (!m.getName().equals(name) || m.getParameterCount() != args.length) {
				continue;
			}
			Class<?>[] types = m.getParameterTypes();
			boolean ok = true;
			for (int i = 0; i < types.length; i++) {
				if (!accepts(types[i], args[i])) {
					ok = false;
					break;
				}
			}
			if (!ok) {
				continue;
			}
			try {
				m.invoke(target, args);
				return true;
			} catch (ReflectiveOperationException | RuntimeException e) {
				// tenta a proxima variante
			}
		}
		return false;
	}

	private static boolean accepts(Class<?> type, Object arg) {
		if (type == boolean.class) {
			return arg instanceof Boolean;
		}
		return arg == null || type.isInstance(arg);
	}

	// ---------------------------------------------------------------- efeito

	private static void onTick(Minecraft mc) {
		if (mc.level == null || mc.gameRenderer == null) {
			effectOn = false;
			return;
		}
		// O Minecraft limpa o efeito de tela ao trocar de dimensao/respawn,
		// entao reaplicamos periodicamente (barato: so troca um campo).
		if (++tickCounter % 10 == 0) {
			apply(mc, false);
		}
	}

	private static void apply(Minecraft mc, boolean force) {
		if (mc.gameRenderer == null) {
			return;
		}
		lookup();
		if (setPostEffect == null) {
			reportOnce("Nao achei o metodo de efeito de tela do Minecraft. " + lookupNote);
			return;
		}
		try {
			if (level <= MIN) {
				if ((effectOn || force) && clearPostEffect != null) {
					clearPostEffect.invoke(mc.gameRenderer);
				}
				effectOn = false;
				return;
			}
			Identifier id = Identifier.fromNamespaceAndPath(MOD_ID, "saturation_" + level);
			setPostEffect.invoke(mc.gameRenderer, id);
			effectOn = true;
		} catch (ReflectiveOperationException | RuntimeException e) {
			reportOnce("Falha ao aplicar o efeito: " + e);
		}
	}

	private static void reportOnce(String text) {
		if (reported) {
			return;
		}
		reported = true;
		System.err.println("[" + MOD_ID + "] " + text);
		say(text);
	}

	/** Procura os metodos do GameRenderer que ligam/desligam o efeito de tela. */
	private static void lookup() {
		if (lookedUp) {
			return;
		}
		lookedUp = true;

		setPostEffect = find(GameRenderer.class, "setPostEffect", Identifier.class);
		clearPostEffect = find(GameRenderer.class, "clearPostEffect");

		if (setPostEffect == null) {
			// Nome diferente nesta versao: aceita so se houver UM candidato claro.
			List<Method> candidates = new ArrayList<>();
			StringBuilder seen = new StringBuilder();
			for (Method m : GameRenderer.class.getDeclaredMethods()) {
				boolean oneId = m.getParameterCount() == 1 && m.getParameterTypes()[0] == Identifier.class;
				if (oneId) {
					seen.append(m.getName()).append(' ');
				}
				if (oneId && m.getReturnType() == void.class && !Modifier.isStatic(m.getModifiers())
						&& m.getName().toLowerCase().contains("effect")) {
					candidates.add(m);
				}
			}
			if (candidates.size() == 1) {
				setPostEffect = candidates.get(0);
				setPostEffect.setAccessible(true);
			} else {
				lookupNote = "Metodos com Identifier no GameRenderer: " + seen;
			}
		}
	}

	private static Method find(Class<?> start, String name, Class<?>... params) {
		for (Class<?> c = start; c != null; c = c.getSuperclass()) {
			try {
				Method m = c.getDeclaredMethod(name, params);
				m.setAccessible(true);
				return m;
			} catch (NoSuchMethodException ignored) {
				// sobe para a superclasse
			}
		}
		return null;
	}

	// ---------------------------------------------------------------- config

	private static Path configPath() {
		return FabricLoader.getInstance().getConfigDir().resolve("saturationboost.properties");
	}

	private static void loadConfig() {
		Path path = configPath();
		if (!Files.exists(path)) {
			saveConfig();
			return;
		}
		Properties props = new Properties();
		try (InputStream in = Files.newInputStream(path)) {
			props.load(in);
			level = snap(Integer.parseInt(props.getProperty("level", "130").trim()));
		} catch (IOException | NumberFormatException e) {
			level = 130;
		}
	}

	private static void saveConfig() {
		Properties props = new Properties();
		props.setProperty("level", Integer.toString(level));
		try (OutputStream out = Files.newOutputStream(configPath())) {
			props.store(out, "Saturation Boost - 100 = normal, 300 = maximo (passos de 10)");
		} catch (IOException ignored) {
			// sem permissao de escrita: o valor so vale ate fechar o jogo
		}
	}
}
