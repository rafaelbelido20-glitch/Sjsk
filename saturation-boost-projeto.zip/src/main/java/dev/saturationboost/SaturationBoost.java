package dev.saturationboost;

import dev.saturationboost.mixin.GameRendererInvoker;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * Saturation Boost: aumenta a saturacao da imagem final do jogo.
 *
 * Controle (chat):  !sat 130   ->  130% de saturacao (100 = normal, maximo 300)
 *                   !sat off   ->  desliga
 *                   !sat       ->  mostra o valor atual
 */
public class SaturationBoost implements ClientModInitializer {

	public static final String MOD_ID = "saturationboost";
	private static final int MIN = 100;
	private static final int MAX = 300;
	private static final int STEP = 10;

	/** 100 = desligado. */
	private static int level = 130;
	private static boolean effectOn = false;
	private static int tickCounter = 0;

	@Override
	public void onInitializeClient() {
		loadConfig();
		ClientSendMessageEvents.ALLOW_CHAT.register(SaturationBoost::onChat);
		ClientTickEvents.END_CLIENT_TICK.register(SaturationBoost::onTick);
	}

	// ---------------------------------------------------------------- chat

	/** Retorna false para impedir o envio da mensagem ao servidor. */
	private static boolean onChat(String message) {
		String text = message.trim();
		if (!text.equalsIgnoreCase("!sat") && !text.toLowerCase().startsWith("!sat ")) {
			return true;
		}

		String arg = text.length() > 4 ? text.substring(4).trim() : "";
		if (arg.isEmpty()) {
			say("Saturacao atual: " + level + "%  (uso: !sat 100-300, !sat off)");
			return false;
		}

		if (arg.equalsIgnoreCase("off")) {
			level = MIN;
		} else {
			try {
				int value = Integer.parseInt(arg.replace("%", ""));
				level = snap(value);
			} catch (NumberFormatException e) {
				say("Valor invalido. Use: !sat 100-300  ou  !sat off");
				return false;
			}
		}

		saveConfig();
		apply(Minecraft.getInstance(), true);
		say(level <= MIN ? "Saturacao desligada." : "Saturacao: " + level + "%");
		return false;
	}

	private static int snap(int value) {
		int clamped = Math.max(MIN, Math.min(MAX, value));
		return Math.round(clamped / (float) STEP) * STEP;
	}

	private static void say(String text) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player != null) {
			mc.player.displayClientMessage(Component.literal("[Saturation Boost] " + text), false);
		}
	}

	// ---------------------------------------------------------------- efeito

	private static void onTick(Minecraft mc) {
		if (mc.level == null || mc.gameRenderer == null) {
			effectOn = false;
			return;
		}
		// O Minecraft limpa o efeito de tela ao trocar de dimensao/respawn,
		// entao reaplicamos periodicamente (barato: so troca um campo).
		if (++tickCounter % 10 == 0) {
			apply(mc, false);
		}
	}

	private static void apply(Minecraft mc, boolean force) {
		if (mc.gameRenderer == null) {
			return;
		}
		GameRendererInvoker renderer = (GameRendererInvoker) mc.gameRenderer;
		if (level <= MIN) {
			if (effectOn || force) {
				renderer.saturationboost$clearPostEffect();
				effectOn = false;
			}
			return;
		}
		renderer.saturationboost$setPostEffect(
				Identifier.fromNamespaceAndPath(MOD_ID, "saturation_" + level));
		effectOn = true;
	}

	// ---------------------------------------------------------------- config

	private static Path configPath() {
		return FabricLoader.getInstance().getConfigDir().resolve("saturationboost.properties");
	}

	private static void loadConfig() {
		Path path = configPath();
		if (!Files.exists(path)) {
			saveConfig();
			return;
		}
		Properties props = new Properties();
		try (InputStream in = Files.newInputStream(path)) {
			props.load(in);
			level = snap(Integer.parseInt(props.getProperty("level", "130").trim()));
		} catch (IOException | NumberFormatException e) {
			level = 130;
		}
	}

	private static void saveConfig() {
		Properties props = new Properties();
		props.setProperty("level", Integer.toString(level));
		try (OutputStream out = Files.newOutputStream(configPath())) {
			props.store(out, "Saturation Boost - 100 = normal, 300 = maximo (passos de 10)");
		} catch (IOException ignored) {
			// sem permissao de escrita: o valor so vale ate fechar o jogo
		}
	}
}
