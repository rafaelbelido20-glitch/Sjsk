#version 330

uniform sampler2D InSampler;

in vec2 texCoord;

out vec4 fragColor;

const float SATURATION = 1.70;

void main() {
    vec4 color = texture(InSampler, texCoord);
    float luma = dot(color.rgb, vec3(0.2126, 0.7152, 0.0722));
    vec3 result = mix(vec3(luma), color.rgb, SATURATION);
    fragColor = vec4(clamp(result, 0.0, 1.0), color.a);
}
